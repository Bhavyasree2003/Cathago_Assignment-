export interface User {
  id: string;
  username: string;
  password: string; // In a real app, this would be hashed
  role: 'user' | 'admin';
  credits: number;
  dailyCreditsReset: string; // ISO date string
  scans: Scan[];
  creditRequests: CreditRequest[];
}

export interface Document {
  id: string;
  userId: string;
  title: string;
  content: string;
  createdAt: string; // ISO date string
  tags: string[];
}

export interface Scan {
  id: string;
  userId: string;
  documentId: string;
  timestamp: string; // ISO date string
  matches: Match[];
}

export interface Match {
  documentId: string;
  score: number; // 0-100 similarity score
}

export interface CreditRequest {
  id: string;
  userId: string;
  amount: number;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  timestamp: string; // ISO date string
  adminId?: string;
  responseTimestamp?: string;
}

export interface Analytics {
  totalScans: number;
  topUsers: {
    userId: string;
    username: string;
    scanCount: number;
  }[];
  topTags: {
    tag: string;
    count: number;
  }[];
  creditUsage: {
    date: string;
    count: number;
  }[];
}