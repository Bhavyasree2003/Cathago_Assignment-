import { atom } from 'jotai';
import { User } from '../types';
import { 
  createUser, 
  loginUser, 
  logoutUser, 
  getCurrentUser, 
  updateUser 
} from '../utils/storage';

// Auth state atom
export const userAtom = atom<User | null>(getCurrentUser());

// Auth actions
export const registerUser = (username: string, password: string): User => {
  try {
    const user = createUser(username, password);
    return user;
  } catch (error) {
    throw error;
  }
};

export const login = (username: string, password: string): User => {
  try {
    const user = loginUser(username, password);
    return user;
  } catch (error) {
    throw error;
  }
};

export const logout = () => {
  logoutUser();
};

export const updateUserData = (user: User): User => {
  try {
    const updatedUser = updateUser(user);
    return updatedUser;
  } catch (error) {
    throw error;
  }
};

// Initialize admin user if it doesn't exist
export const initializeAdmin = () => {
  try {
    const users = getCurrentUser();
    if (!users) {
      createUser('admin', 'admin123', 'admin');
    }
  } catch (error) {
    console.error('Error initializing admin:', error);
  }
};