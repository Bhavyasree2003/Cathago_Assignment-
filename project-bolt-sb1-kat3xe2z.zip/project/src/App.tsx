import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAtom } from 'jotai';
import { userAtom, initializeAdmin } from './store/auth';

// Components
import Layout from './components/Layout';

// Pages
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import ScanDocument from './pages/ScanDocument';
import Documents from './pages/Documents';
import Credits from './pages/Credits';
import CreditRequests from './pages/admin/CreditRequests';
import Analytics from './pages/admin/Analytics';

function App() {
  const [user] = useAtom(userAtom);

  useEffect(() => {
    // Initialize admin user if it doesn't exist
    initializeAdmin();
  }, []);

  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        
        <Route path="/" element={<Layout><Dashboard /></Layout>} />
        <Route path="/dashboard" element={<Layout><Dashboard /></Layout>} />
        <Route path="/scan" element={<Layout><ScanDocument /></Layout>} />
        <Route path="/documents" element={<Layout><Documents /></Layout>} />
        <Route path="/credits" element={<Layout><Credits /></Layout>} />
        
        {/* Admin routes */}
        <Route path="/admin/requests" element={<Layout><CreditRequests /></Layout>} />
        <Route path="/admin/analytics" element={<Layout><Analytics /></Layout>} />
        
        {/* Redirect to dashboard if logged in, otherwise to login */}
        <Route path="*" element={user ? <Navigate to="/dashboard" /> : <Navigate to="/login" />} />
      </Routes>
    </Router>
  );
}

export default App;