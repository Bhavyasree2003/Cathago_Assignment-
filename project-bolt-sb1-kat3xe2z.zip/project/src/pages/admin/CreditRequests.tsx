import React, { useState, useEffect } from 'react';
import { useAtom } from 'jotai';
import { userAtom } from '../../store/auth';
import { getPendingCreditRequests, updateCreditRequest, getUsers } from '../../utils/storage';
import { CreditRequest, User } from '../../types';
import { Check, X, Clock } from 'lucide-react';

const CreditRequests: React.FC = () => {
  const [user] = useAtom(userAtom);
  const [pendingRequests, setPendingRequests] = useState<CreditRequest[]>([]);
  const [users, setUsers] = useState<Record<string, User>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user?.role !== 'admin') {
      return;
    }

    // Get all pending credit requests
    const requests = getPendingCreditRequests();
    setPendingRequests(requests);

    // Get all users for displaying usernames
    const allUsers = getUsers();
    const usersMap: Record<string, User> = {};
    allUsers.forEach((u) => {
      usersMap[u.id] = u;
    });
    setUsers(usersMap);

    setLoading(false);
  }, [user]);

  const handleApprove = (requestId: string) => {
    if (!user) return;

    try {
      updateCreditRequest(requestId, 'approved', user.id);
      
      // Update the local state
      setPendingRequests(pendingRequests.filter((req) => req.id !== requestId));
    } catch (err) {
      console.error('Failed to approve request:', err);
    }
  };

  const handleReject = (requestId: string) => {
    if (!user) return;

    try {
      updateCreditRequest(requestId, 'rejected', user.id);
      
      // Update the local state
      setPendingRequests(pendingRequests.filter((req) => req.id !== requestId));
    } catch (err) {
      console.error('Failed to reject request:', err);
    }
  };

  if (user?.role !== 'admin') {
    return (
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h1 className="text-xl font-semibold text-gray-800 mb-4">Access Denied</h1>
        <p className="text-gray-600">You do not have permission to view this page.</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h1 className="text-xl font-semibold text-gray-800 mb-4">Credit Requests</h1>
        <p className="text-gray-600">Loading...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h1 className="text-xl font-semibold text-gray-800 mb-6">Pending Credit Requests</h1>

        {pendingRequests.length === 0 ? (
          <div className="text-center py-12">
            <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900">No pending requests</h3>
            <p className="mt-2 text-sm text-gray-500">
              All credit requests have been processed.
            </p>
          </div>
        ) : (
          <div className="border rounded-lg overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    User
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Amount
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Reason
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {pendingRequests.map((request) => (
                  <tr key={request.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {users[request.userId]?.username || 'Unknown User'}
                      </div>
                      <div className="text-sm text-gray-500">
                        Current Credits: {users[request.userId]?.credits || 0}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(request.timestamp).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {request.amount}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">
                      {request.reason}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleApprove(request.id)}
                          className="inline-flex items-center px-3 py-1 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-green-600 hover:bg-green-700"
                        >
                          <Check className="h-4 w-4 mr-1" />
                          Approve
                        </button>
                        <button
                          onClick={() => handleReject(request.id)}
                          className="inline-flex items-center px-3 py-1 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-red-600 hover:bg-red-700"
                        >
                          <X className="h-4 w-4 mr-1" />
                          Reject
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default CreditRequests;