import React, { useEffect, useState } from 'react';
import { useAtom } from 'jotai';
import { userAtom } from '../../store/auth';
import { getAnalytics } from '../../utils/storage';
import { Analytics } from '../../types';
import { BarChart2, Users, Tag, CreditCard } from 'lucide-react';

const AnalyticsDashboard: React.FC = () => {
  const [user] = useAtom(userAtom);
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user?.role !== 'admin') {
      return;
    }

    try {
      const data = getAnalytics();
      setAnalytics(data);
    } catch (err) {
      console.error('Failed to load analytics:', err);
    } finally {
      setLoading(false);
    }
  }, [user]);

  if (user?.role !== 'admin') {
    return (
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h1 className="text-xl font-semibold text-gray-800 mb-4">Access Denied</h1>
        <p className="text-gray-600">You do not have permission to view this page.</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h1 className="text-xl font-semibold text-gray-800 mb-4">Analytics</h1>
        <p className="text-gray-600">Loading...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h1 className="text-xl font-semibold text-gray-800 mb-6">Analytics Dashboard</h1>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-blue-50 p-4 rounded-lg">
            <div className="flex items-center">
              <div className="bg-blue-100 p-3 rounded-full">
                <BarChart2 className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <h3 className="text-sm font-medium text-gray-500">Total Scans</h3>
                <p className="text-2xl font-semibold text-gray-900">{analytics?.totalScans || 0}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-green-50 p-4 rounded-lg">
            <div className="flex items-center">
              <div className="bg-green-100 p-3 rounded-full">
                <Users className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-4">
                <h3 className="text-sm font-medium text-gray-500">Active Users</h3>
                <p className="text-2xl font-semibold text-gray-900">{analytics?.topUsers.length || 0}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-purple-50 p-4 rounded-lg">
            <div className="flex items-center">
              <div className="bg-purple-100 p-3 rounded-full">
                <Tag className="h-6 w-6 text-purple-600" />
              </div>
              <div className="ml-4">
                <h3 className="text-sm font-medium text-gray-500">Popular Tags</h3>
                <p className="text-2xl font-semibold text-gray-900">{analytics?.topTags.length || 0}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-yellow-50 p-4 rounded-lg">
            <div className="flex items-center">
              <div className="bg-yellow-100 p-3 rounded-full">
                <CreditCard className="h-6 w-6 text-yellow-600" />
              </div>
              <div className="ml-4">
                <h3 className="text-sm font-medium text-gray-500">Credit Usage</h3>
                <p className="text-2xl font-semibold text-gray-900">
                  {analytics?.creditUsage.reduce((sum, item) => sum + item.count, 0) || 0}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Top Users */}
        <div className="mb-8">
          <h2 className="text-lg font-medium text-gray-800 mb-4">Top Users by Scan Count</h2>
          
          {analytics?.topUsers && analytics.topUsers.length > 0 ? (
            <div className="bg-white border rounded-lg overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Rank
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Username
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Scan Count
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {analytics.topUsers.map((user, index) => (
                    <tr key={user.userId}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {index + 1}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {user.username}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {user.scanCount}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-gray-500">No user data available.</p>
          )}
        </div>

        {/* Popular Tags */}
        <div className="mb-8">
          <h2 className="text-lg font-medium text-gray-800 mb-4">Popular Document Tags</h2>
          
          {analytics?.topTags && analytics.topTags.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {analytics.topTags.map((tag) => (
                <div key={tag.tag} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center">
                    <Tag className="h-5 w-5 text-gray-500 mr-3" />
                    <span className="text-gray-800 font-medium">{tag.tag}</span>
                  </div>
                  <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded-full">
                    {tag.count} documents
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500">No tag data available.</p>
          )}
        </div>

        {/* Credit Usage Over Time */}
        <div>
          <h2 className="text-lg font-medium text-gray-800 mb-4">Credit Usage Over Time</h2>
          
          {analytics?.creditUsage && analytics.creditUsage.length > 0 ? (
            <div className="bg-white border rounded-lg overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Credits Used
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {analytics.creditUsage.map((usage) => (
                    <tr key={usage.date}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {usage.date}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {usage.count}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-gray-500">No credit usage data available.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default AnalyticsDashboard;