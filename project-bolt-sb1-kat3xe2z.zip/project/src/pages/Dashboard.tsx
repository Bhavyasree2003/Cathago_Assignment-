import React, { useEffect, useState } from 'react';
import { useAtom } from 'jotai';
import { userAtom } from '../store/auth';
import { getUserDocuments, getUserScans } from '../utils/storage';
import { Document, Scan } from '../types';
import { FileText, Clock, Search } from 'lucide-react';
import { Link } from 'react-router-dom';

const Dashboard: React.FC = () => {
  const [user] = useAtom(userAtom);
  const [documents, setDocuments] = useState<Document[]>([]);
  const [recentScans, setRecentScans] = useState<Scan[]>([]);

  useEffect(() => {
    if (user) {
      const userDocs = getUserDocuments(user.id);
      setDocuments(userDocs);

      const userScans = getUserScans(user.id);
      setRecentScans(userScans.slice(0, 5)); // Get 5 most recent scans
    }
  }, [user]);

  if (!user) return null;

  return (
    <div className="space-y-6">
      {/* Welcome section */}
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h1 className="text-2xl font-bold text-gray-800">Welcome, {user.username}!</h1>
        <p className="text-gray-600 mt-2">
          You have <span className="font-semibold">{user.credits}</span> credits available.
        </p>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Link
          to="/scan"
          className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow flex items-center space-x-4"
        >
          <div className="bg-blue-100 p-3 rounded-full">
            <Search className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-800">Scan Document</h3>
            <p className="text-sm text-gray-600">Upload and scan a document</p>
          </div>
        </Link>
        <Link
          to="/documents"
          className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow flex items-center space-x-4"
        >
          <div className="bg-green-100 p-3 rounded-full">
            <FileText className="h-6 w-6 text-green-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-800">My Documents</h3>
            <p className="text-sm text-gray-600">View your uploaded documents</p>
          </div>
        </Link>
        <Link
          to="/credits"
          className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow flex items-center space-x-4"
        >
          <div className="bg-purple-100 p-3 rounded-full">
            <Clock className="h-6 w-6 text-purple-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-800">Request Credits</h3>
            <p className="text-sm text-gray-600">Request additional credits</p>
          </div>
        </Link>
      </div>

      {/* Recent documents */}
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">Recent Documents</h2>
        {documents.length > 0 ? (
          <div className="space-y-3">
            {documents.slice(0, 5).map((doc) => (
              <div key={doc.id} className="flex items-center p-3 border rounded-md hover:bg-gray-50">
                <FileText className="h-5 w-5 text-gray-500 mr-3" />
                <div>
                  <h3 className="font-medium text-gray-800">{doc.title}</h3>
                  <p className="text-sm text-gray-500">
                    {new Date(doc.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500">No documents yet. Upload your first document!</p>
        )}
      </div>

      {/* Recent scans */}
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">Recent Scans</h2>
        {recentScans.length > 0 ? (
          <div className="space-y-3">
            {recentScans.map((scan) => {
              const doc = documents.find((d) => d.id === scan.documentId);
              return (
                <div key={scan.id} className="flex items-center p-3 border rounded-md hover:bg-gray-50">
                  <Search className="h-5 w-5 text-gray-500 mr-3" />
                  <div>
                    <h3 className="font-medium text-gray-800">
                      {doc ? doc.title : 'Unknown Document'}
                    </h3>
                    <p className="text-sm text-gray-500">
                      {new Date(scan.timestamp).toLocaleDateString()} • 
                      {scan.matches.length} matches found
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <p className="text-gray-500">No scans yet. Start scanning documents!</p>
        )}
      </div>
    </div>
  );
};

export default Dashboard;