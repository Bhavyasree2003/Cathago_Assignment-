import React, { useState, useEffect } from 'react';
import { useAtom } from 'jotai';
import { userAtom } from '../store/auth';
import { createCreditRequest } from '../utils/storage';
import { CreditRequest } from '../types';
import { CreditCard, Clock, Check, X } from 'lucide-react';

const Credits: React.FC = () => {
  const [user, setUser] = useAtom(userAtom);
  const [amount, setAmount] = useState(10);
  const [reason, setReason] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [creditRequests, setCreditRequests] = useState<CreditRequest[]>([]);

  useEffect(() => {
    if (user) {
      setCreditRequests(user.creditRequests);
    }
  }, [user]);

  const handleRequestCredits = () => {
    setError('');
    setSuccess('');

    if (!user) {
      setError('You must be logged in to request credits');
      return;
    }

    if (amount <= 0) {
      setError('Please enter a valid amount');
      return;
    }

    if (!reason.trim()) {
      setError('Please provide a reason for your request');
      return;
    }

    try {
      const request = createCreditRequest(user.id, amount, reason);
      setCreditRequests([...creditRequests, request]);
      setSuccess('Credit request submitted successfully');
      setAmount(10);
      setReason('');
      
      // Update user state with the new credit request
      if (user) {
        setUser({
          ...user,
          creditRequests: [...user.creditRequests, request],
        });
      }
    } catch (err) {
      setError('Failed to submit credit request');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'text-green-600 bg-green-100';
      case 'rejected':
        return 'text-red-600 bg-red-100';
      default:
        return 'text-yellow-600 bg-yellow-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <Check className="h-4 w-4" />;
      case 'rejected':
        return <X className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h1 className="text-xl font-semibold text-gray-800 mb-6">Credits</h1>
        
        <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg mb-6">
          <div className="flex items-center">
            <CreditCard className="h-8 w-8 text-blue-500 mr-4" />
            <div>
              <h2 className="text-lg font-medium text-gray-800">Current Credits</h2>
              <p className="text-gray-600">You have {user?.credits || 0} credits available</p>
            </div>
          </div>
          <div className="text-3xl font-bold text-blue-600">{user?.credits || 0}</div>
        </div>

        <div className="bg-gray-50 p-4 rounded-lg mb-6">
          <h2 className="text-lg font-medium text-gray-800 mb-4">Request More Credits</h2>
          
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-md p-3 mb-4">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          )}
          
          {success && (
            <div className="bg-green-50 border border-green-200 rounded-md p-3 mb-4">
              <p className="text-sm text-green-700">{success}</p>
            </div>
          )}
          
          <div className="space-y-4">
            <div>
              <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-1">
                Amount
              </label>
              <input
                type="number"
                id="amount"
                min="1"
                value={amount}
                onChange={(e) => setAmount(parseInt(e.target.value) || 0)}
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            
            <div>
              <label htmlFor="reason" className="block text-sm font-medium text-gray-700 mb-1">
                Reason
              </label>
              <textarea
                id="reason"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                rows={3}
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                placeholder="Explain why you need additional credits"
              />
            </div>
            
            <div className="flex justify-end">
              <button
                onClick={handleRequestCredits}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                Submit Request
              </button>
            </div>
          </div>
        </div>

        <div>
          <h2 className="text-lg font-medium text-gray-800 mb-4">Credit Request History</h2>
          
          {creditRequests.length > 0 ? (
            <div className="border rounded-lg overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Amount
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Reason
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {creditRequests.map((request) => (
                    <tr key={request.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(request.timestamp).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {request.amount}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">
                        {request.reason}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(request.status)}`}>
                          {getStatusIcon(request.status)}
                          <span className="ml-1 capitalize">{request.status}</span>
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-gray-500">No credit requests yet.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Credits;