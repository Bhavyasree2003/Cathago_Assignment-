import React, { useState, useEffect } from 'react';
import { useAtom } from 'jotai';
import { userAtom } from '../store/auth';
import { createDocument, getDocuments, createScan, updateUser } from '../utils/storage';
import { findMatchingDocuments, extractTags } from '../utils/documentMatcher';
import { Document } from '../types';
import { Upload, AlertCircle, Check } from 'lucide-react';
import { Link } from 'react-router-dom';

const ScanDocument: React.FC = () => {
  const [user, setUser] = useAtom(userAtom);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [error, setError] = useState('');
  const [scanResults, setScanResults] = useState<{ documentId: string; score: number }[]>([]);
  const [allDocuments, setAllDocuments] = useState<Document[]>([]);
  const [scanComplete, setScanComplete] = useState(false);

  useEffect(() => {
    setAllDocuments(getDocuments());
  }, []);

  const handleScan = () => {
    setError('');
    setScanResults([]);
    setScanComplete(false);

    if (!title.trim() || !content.trim()) {
      setError('Please provide both title and content');
      return;
    }

    if (!user) {
      setError('You must be logged in to scan documents');
      return;
    }

    if (user.credits <= 0) {
      setError('You do not have enough credits to perform a scan');
      return;
    }

    setIsScanning(true);

    // Simulate scanning delay
    setTimeout(() => {
      try {
        // Extract tags from content
        const tags = extractTags(content);

        // Create new document
        const newDocument = createDocument(user.id, title, content, tags);

        // Find matching documents (excluding the one just created)
        const existingDocs = allDocuments.filter(doc => doc.userId !== user.id);
        const matches = findMatchingDocuments(content, existingDocs);

        // Create scan record
        createScan(user.id, newDocument.id, matches);

        // Update user's credits
        if (user) {
          const updatedUser = { ...user, credits: user.credits - 1 };
          updateUser(updatedUser);
          setUser(updatedUser);
        }

        // Update state with results
        setScanResults(matches);
        setAllDocuments([...allDocuments, newDocument]);
        setScanComplete(true);
        setIsScanning(false);
      } catch (err) {
        setError('An error occurred during scanning');
        setIsScanning(false);
      }
    }, 1500);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Only accept text files
    if (file.type !== 'text/plain') {
      setError('Only plain text (.txt) files are supported');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setContent(content);
      
      // Auto-generate title from filename if not set
      if (!title) {
        setTitle(file.name.replace('.txt', ''));
      }
    };
    reader.onerror = () => {
      setError('Error reading file');
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h1 className="text-xl font-semibold text-gray-800 mb-4">Scan Document</h1>
        
        {user && user.credits <= 0 && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4 mb-6">
            <div className="flex">
              <AlertCircle className="h-5 w-5 text-yellow-500 mr-2" />
              <div>
                <h3 className="text-sm font-medium text-yellow-800">Credit limit reached</h3>
                <p className="text-sm text-yellow-700 mt-1">
                  You have no credits left. Please wait for your daily reset or{' '}
                  <Link to="/credits" className="font-medium underline">
                    request more credits
                  </Link>
                  .
                </p>
              </div>
            </div>
          </div>
        )}

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-md p-4 mb-6">
            <div className="flex">
              <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        )}

        {scanComplete ? (
          <div className="space-y-6">
            <div className="bg-green-50 border border-green-200 rounded-md p-4">
              <div className="flex">
                <Check className="h-5 w-5 text-green-500 mr-2" />
                <div>
                  <h3 className="text-sm font-medium text-green-800">Scan complete</h3>
                  <p className="text-sm text-green-700 mt-1">
                    Your document has been scanned and {scanResults.length} matching documents were found.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-6">
              <h2 className="text-lg font-medium text-gray-800 mb-3">Matching Documents</h2>
              {scanResults.length > 0 ? (
                <div className="space-y-3">
                  {scanResults.map((result) => {
                    const doc = allDocuments.find((d) => d.id === result.documentId);
                    return (
                      <div key={result.documentId} className="border rounded-md p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-medium text-gray-800">{doc?.title || 'Unknown Document'}</h3>
                            <p className="text-sm text-gray-500 mt-1">
                              Created: {doc ? new Date(doc.createdAt).toLocaleDateString() : 'Unknown'}
                            </p>
                          </div>
                          <div className="bg-blue-100 text-blue-800 text-sm font-medium px-2.5 py-0.5 rounded">
                            {result.score}% match
                          </div>
                        </div>
                        <div className="mt-3">
                          <p className="text-sm text-gray-600 line-clamp-3">
                            {doc?.content.substring(0, 150)}...
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <p className="text-gray-500">No matching documents found.</p>
              )}
            </div>

            <div className="flex justify-end mt-6">
              <button
                onClick={() => {
                  setTitle('');
                  setContent('');
                  setScanResults([]);
                  setScanComplete(false);
                }}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                Scan Another Document
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700">
                Document Title
              </label>
              <input
                type="text"
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter document title"
              />
            </div>

            <div>
              <label htmlFor="content" className="block text-sm font-medium text-gray-700">
                Document Content
              </label>
              <textarea
                id="content"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                rows={10}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                placeholder="Paste document content here or upload a file"
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="relative">
                <input
                  type="file"
                  id="file-upload"
                  accept=".txt"
                  onChange={handleFileUpload}
                  className="sr-only"
                />
                <label
                  htmlFor="file-upload"
                  className="flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 cursor-pointer"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Text File
                </label>
              </div>

              <div className="flex items-center">
                <span className="text-sm text-gray-500 mr-4">
                  Credits: <span className="font-medium">{user?.credits || 0}</span>
                </span>
                <button
                  onClick={handleScan}
                  disabled={isScanning || !title || !content || (user?.credits || 0) <= 0}
                  className={`px-4 py-2 rounded-md ${
                    isScanning || !title || !content || (user?.credits || 0) <= 0
                      ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                      : 'bg-blue-600 text-white hover:bg-blue-700'
                  }`}
                >
                  {isScanning ? 'Scanning...' : 'Scan Document'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ScanDocument;