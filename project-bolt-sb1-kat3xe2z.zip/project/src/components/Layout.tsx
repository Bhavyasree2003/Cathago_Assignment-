import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { User, LogOut, FileText, CreditCard, BarChart2, Users } from 'lucide-react';
import { userAtom } from '../store/auth';
import { useAtom } from 'jotai';
import { logout } from '../store/auth';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [user] = useAtom(userAtom);
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  if (!user && !location.pathname.includes('/login') && !location.pathname.includes('/register')) {
    navigate('/login');
    return null;
  }

  // If on login or register page, don't show the layout
  if (location.pathname.includes('/login') || location.pathname.includes('/register')) {
    return <>{children}</>;
  }

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-md">
        <div className="p-4 border-b">
          <h1 className="text-xl font-semibold text-gray-800">DocScanner</h1>
        </div>
        <nav className="mt-4">
          <ul>
            <li>
              <Link
                to="/dashboard"
                className={`flex items-center px-4 py-3 ${
                  location.pathname === '/dashboard' ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                <FileText className="w-5 h-5 mr-3" />
                Dashboard
              </Link>
            </li>
            <li>
              <Link
                to="/scan"
                className={`flex items-center px-4 py-3 ${
                  location.pathname === '/scan' ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                <FileText className="w-5 h-5 mr-3" />
                Scan Document
              </Link>
            </li>
            <li>
              <Link
                to="/documents"
                className={`flex items-center px-4 py-3 ${
                  location.pathname === '/documents' ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                <FileText className="w-5 h-5 mr-3" />
                My Documents
              </Link>
            </li>
            <li>
              <Link
                to="/credits"
                className={`flex items-center px-4 py-3 ${
                  location.pathname === '/credits' ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                <CreditCard className="w-5 h-5 mr-3" />
                Credits
              </Link>
            </li>
            {user?.role === 'admin' && (
              <>
                <li>
                  <Link
                    to="/admin/requests"
                    className={`flex items-center px-4 py-3 ${
                      location.pathname === '/admin/requests' ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <Users className="w-5 h-5 mr-3" />
                    Credit Requests
                  </Link>
                </li>
                <li>
                  <Link
                    to="/admin/analytics"
                    className={`flex items-center px-4 py-3 ${
                      location.pathname === '/admin/analytics' ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <BarChart2 className="w-5 h-5 mr-3" />
                    Analytics
                  </Link>
                </li>
              </>
            )}
          </ul>
        </nav>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white shadow-sm">
          <div className="flex items-center justify-between px-6 py-3">
            <h2 className="text-lg font-medium text-gray-800">
              {location.pathname === '/dashboard' && 'Dashboard'}
              {location.pathname === '/scan' && 'Scan Document'}
              {location.pathname === '/documents' && 'My Documents'}
              {location.pathname === '/credits' && 'Credits'}
              {location.pathname === '/admin/requests' && 'Credit Requests'}
              {location.pathname === '/admin/analytics' && 'Analytics'}
            </h2>
            <div className="flex items-center">
              <div className="mr-4">
                <span className="text-sm text-gray-600">Credits: </span>
                <span className="font-medium">{user?.credits || 0}</span>
              </div>
              <div className="flex items-center">
                <User className="w-5 h-5 mr-2 text-gray-500" />
                <span className="text-sm font-medium text-gray-700 mr-4">{user?.username}</span>
                <button
                  onClick={handleLogout}
                  className="flex items-center text-gray-600 hover:text-gray-800"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-6 bg-gray-50">
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;