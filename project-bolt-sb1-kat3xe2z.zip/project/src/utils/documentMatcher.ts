import { Document } from '../types';

// Basic text similarity algorithm using Levenshtein distance
const levenshteinDistance = (a: string, b: string): number => {
  const matrix: number[][] = [];

  // Initialize matrix
  for (let i = 0; i <= b.length; i++) {
    matrix[i] = [i];
  }
  
  for (let j = 0; j <= a.length; j++) {
    matrix[0][j] = j;
  }
  
  // Fill matrix
  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1, // substitution
          matrix[i][j - 1] + 1,     // insertion
          matrix[i - 1][j] + 1      // deletion
        );
      }
    }
  }
  
  return matrix[b.length][a.length];
};

// Calculate similarity score (0-100) based on Levenshtein distance
const calculateSimilarityScore = (a: string, b: string): number => {
  if (a.length === 0 && b.length === 0) return 100;
  if (a.length === 0 || b.length === 0) return 0;
  
  const distance = levenshteinDistance(a, b);
  const maxLength = Math.max(a.length, b.length);
  const similarity = (1 - distance / maxLength) * 100;
  
  return Math.round(similarity);
};

// Word frequency analysis
const getWordFrequency = (text: string): Record<string, number> => {
  const words = text.toLowerCase().match(/\b\w+\b/g) || [];
  const frequency: Record<string, number> = {};
  
  words.forEach(word => {
    frequency[word] = (frequency[word] || 0) + 1;
  });
  
  return frequency;
};

// Calculate cosine similarity between word frequency vectors
const calculateCosineSimilarity = (a: Record<string, number>, b: Record<string, number>): number => {
  const allWords = new Set([...Object.keys(a), ...Object.keys(b)]);
  
  let dotProduct = 0;
  let magnitudeA = 0;
  let magnitudeB = 0;
  
  allWords.forEach(word => {
    const freqA = a[word] || 0;
    const freqB = b[word] || 0;
    
    dotProduct += freqA * freqB;
    magnitudeA += freqA * freqA;
    magnitudeB += freqB * freqB;
  });
  
  magnitudeA = Math.sqrt(magnitudeA);
  magnitudeB = Math.sqrt(magnitudeB);
  
  if (magnitudeA === 0 || magnitudeB === 0) return 0;
  
  const similarity = dotProduct / (magnitudeA * magnitudeB);
  return Math.round(similarity * 100);
};

// Find matching documents based on content similarity
export const findMatchingDocuments = (sourceContent: string, documents: Document[], threshold = 30): { documentId: string; score: number }[] => {
  const sourceFrequency = getWordFrequency(sourceContent);
  
  const matches = documents.map(doc => {
    const targetFrequency = getWordFrequency(doc.content);
    const frequencyScore = calculateCosineSimilarity(sourceFrequency, targetFrequency);
    
    // For short documents, also use Levenshtein distance
    const levenshteinScore = sourceContent.length < 1000 && doc.content.length < 1000
      ? calculateSimilarityScore(sourceContent, doc.content)
      : 0;
    
    // Combine scores with more weight on frequency for longer documents
    const combinedScore = sourceContent.length > 500
      ? Math.round(frequencyScore * 0.8 + levenshteinScore * 0.2)
      : Math.round(frequencyScore * 0.5 + levenshteinScore * 0.5);
    
    return {
      documentId: doc.id,
      score: combinedScore,
    };
  });
  
  // Filter by threshold and sort by score (descending)
  return matches
    .filter(match => match.score >= threshold)
    .sort((a, b) => b.score - a.score);
};

// Extract tags from document content
export const extractTags = (content: string): string[] => {
  const words = content.toLowerCase().match(/\b\w+\b/g) || [];
  const frequency: Record<string, number> = {};
  
  words.forEach(word => {
    // Skip common words and short words
    if (word.length < 4 || ['the', 'and', 'that', 'have', 'this', 'with'].includes(word)) {
      return;
    }
    frequency[word] = (frequency[word] || 0) + 1;
  });
  
  // Get top 5 most frequent words as tags
  return Object.entries(frequency)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([word]) => word);
};