import { User, Document, Scan, CreditRequest, Analytics } from '../types';
import { startOfDay, addDays, parseISO, isAfter } from 'date-fns';

// Mock database using localStorage
const STORAGE_KEYS = {
  USERS: 'doc_scanner_users',
  DOCUMENTS: 'doc_scanner_documents',
  SCANS: 'doc_scanner_scans',
  CREDIT_REQUESTS: 'doc_scanner_credit_requests',
  CURRENT_USER: 'doc_scanner_current_user',
};

// Initialize storage
const initializeStorage = () => {
  if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify([]));
  }
  if (!localStorage.getItem(STORAGE_KEYS.DOCUMENTS)) {
    localStorage.setItem(STORAGE_KEYS.DOCUMENTS, JSON.stringify([]));
  }
  if (!localStorage.getItem(STORAGE_KEYS.SCANS)) {
    localStorage.setItem(STORAGE_KEYS.SCANS, JSON.stringify([]));
  }
  if (!localStorage.getItem(STORAGE_KEYS.CREDIT_REQUESTS)) {
    localStorage.setItem(STORAGE_KEYS.CREDIT_REQUESTS, JSON.stringify([]));
  }
};

// User functions
export const getUsers = (): User[] => {
  initializeStorage();
  return JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
};

export const saveUsers = (users: User[]) => {
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
};

export const getCurrentUser = (): User | null => {
  const userId = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
  if (!userId) return null;
  
  const users = getUsers();
  return users.find(user => user.id === userId) || null;
};

export const setCurrentUser = (userId: string | null) => {
  if (userId) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, userId);
  } else {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  }
};

export const createUser = (username: string, password: string, role: 'user' | 'admin' = 'user'): User => {
  const users = getUsers();
  
  // Check if username already exists
  if (users.some(user => user.username === username)) {
    throw new Error('Username already exists');
  }
  
  const newUser: User = {
    id: crypto.randomUUID(),
    username,
    password, // In a real app, this would be hashed
    role,
    credits: 20,
    dailyCreditsReset: new Date().toISOString(),
    scans: [],
    creditRequests: [],
  };
  
  users.push(newUser);
  saveUsers(users);
  return newUser;
};

export const loginUser = (username: string, password: string): User => {
  const users = getUsers();
  const user = users.find(u => u.username === username && u.password === password);
  
  if (!user) {
    throw new Error('Invalid username or password');
  }
  
  // Check if daily credits need to be reset
  const today = startOfDay(new Date());
  const lastReset = parseISO(user.dailyCreditsReset);
  
  if (isAfter(today, lastReset)) {
    user.credits = Math.max(user.credits, 20); // Ensure at least 20 credits
    user.dailyCreditsReset = today.toISOString();
    saveUsers(users);
  }
  
  setCurrentUser(user.id);
  return user;
};

export const logoutUser = () => {
  setCurrentUser(null);
};

export const updateUser = (updatedUser: User) => {
  const users = getUsers();
  const index = users.findIndex(u => u.id === updatedUser.id);
  
  if (index === -1) {
    throw new Error('User not found');
  }
  
  users[index] = updatedUser;
  saveUsers(users);
  return updatedUser;
};

// Document functions
export const getDocuments = (): Document[] => {
  initializeStorage();
  return JSON.parse(localStorage.getItem(STORAGE_KEYS.DOCUMENTS) || '[]');
};

export const saveDocuments = (documents: Document[]) => {
  localStorage.setItem(STORAGE_KEYS.DOCUMENTS, JSON.stringify(documents));
};

export const createDocument = (userId: string, title: string, content: string, tags: string[] = []): Document => {
  const documents = getDocuments();
  
  const newDocument: Document = {
    id: crypto.randomUUID(),
    userId,
    title,
    content,
    createdAt: new Date().toISOString(),
    tags,
  };
  
  documents.push(newDocument);
  saveDocuments(documents);
  return newDocument;
};

export const getDocumentById = (id: string): Document | null => {
  const documents = getDocuments();
  return documents.find(doc => doc.id === id) || null;
};

export const getUserDocuments = (userId: string): Document[] => {
  const documents = getDocuments();
  return documents.filter(doc => doc.userId === userId);
};

// Scan functions
export const getScans = (): Scan[] => {
  initializeStorage();
  return JSON.parse(localStorage.getItem(STORAGE_KEYS.SCANS) || '[]');
};

export const saveScans = (scans: Scan[]) => {
  localStorage.setItem(STORAGE_KEYS.SCANS, JSON.stringify(scans));
};

export const createScan = (userId: string, documentId: string, matches: { documentId: string; score: number }[]): Scan => {
  const scans = getScans();
  
  const newScan: Scan = {
    id: crypto.randomUUID(),
    userId,
    documentId,
    timestamp: new Date().toISOString(),
    matches,
  };
  
  scans.push(newScan);
  saveScans(scans);
  
  // Update user's scan history and deduct credit
  const users = getUsers();
  const userIndex = users.findIndex(u => u.id === userId);
  
  if (userIndex !== -1) {
    users[userIndex].credits -= 1;
    users[userIndex].scans.push(newScan);
    saveUsers(users);
  }
  
  return newScan;
};

export const getUserScans = (userId: string): Scan[] => {
  const scans = getScans();
  return scans.filter(scan => scan.userId === userId);
};

// Credit request functions
export const getCreditRequests = (): CreditRequest[] => {
  initializeStorage();
  return JSON.parse(localStorage.getItem(STORAGE_KEYS.CREDIT_REQUESTS) || '[]');
};

export const saveCreditRequests = (requests: CreditRequest[]) => {
  localStorage.setItem(STORAGE_KEYS.CREDIT_REQUESTS, JSON.stringify(requests));
};

export const createCreditRequest = (userId: string, amount: number, reason: string): CreditRequest => {
  const requests = getCreditRequests();
  
  const newRequest: CreditRequest = {
    id: crypto.randomUUID(),
    userId,
    amount,
    reason,
    status: 'pending',
    timestamp: new Date().toISOString(),
  };
  
  requests.push(newRequest);
  saveCreditRequests(requests);
  
  // Update user's credit requests
  const users = getUsers();
  const userIndex = users.findIndex(u => u.id === userId);
  
  if (userIndex !== -1) {
    users[userIndex].creditRequests.push(newRequest);
    saveUsers(users);
  }
  
  return newRequest;
};

export const updateCreditRequest = (requestId: string, status: 'approved' | 'rejected', adminId: string): CreditRequest => {
  const requests = getCreditRequests();
  const requestIndex = requests.findIndex(req => req.id === requestId);
  
  if (requestIndex === -1) {
    throw new Error('Credit request not found');
  }
  
  requests[requestIndex].status = status;
  requests[requestIndex].adminId = adminId;
  requests[requestIndex].responseTimestamp = new Date().toISOString();
  
  saveCreditRequests(requests);
  
  // If approved, add credits to user
  if (status === 'approved') {
    const users = getUsers();
    const userIndex = users.findIndex(u => u.id === requests[requestIndex].userId);
    
    if (userIndex !== -1) {
      users[userIndex].credits += requests[requestIndex].amount;
      saveUsers(users);
    }
  }
  
  return requests[requestIndex];
};

export const getPendingCreditRequests = (): CreditRequest[] => {
  const requests = getCreditRequests();
  return requests.filter(req => req.status === 'pending');
};

// Analytics functions
export const getAnalytics = (): Analytics => {
  const scans = getScans();
  const users = getUsers();
  const documents = getDocuments();
  
  // Total scans
  const totalScans = scans.length;
  
  // Top users by scan count
  const userScanCounts: Record<string, number> = {};
  scans.forEach(scan => {
    userScanCounts[scan.userId] = (userScanCounts[scan.userId] || 0) + 1;
  });
  
  const topUsers = Object.entries(userScanCounts)
    .map(([userId, count]) => {
      const user = users.find(u => u.id === userId);
      return {
        userId,
        username: user?.username || 'Unknown',
        scanCount: count,
      };
    })
    .sort((a, b) => b.scanCount - a.scanCount)
    .slice(0, 5);
  
  // Top tags
  const tagCounts: Record<string, number> = {};
  documents.forEach(doc => {
    doc.tags.forEach(tag => {
      tagCounts[tag] = (tagCounts[tag] || 0) + 1;
    });
  });
  
  const topTags = Object.entries(tagCounts)
    .map(([tag, count]) => ({ tag, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);
  
  // Credit usage by date
  const creditUsageByDate: Record<string, number> = {};
  scans.forEach(scan => {
    const date = scan.timestamp.split('T')[0];
    creditUsageByDate[date] = (creditUsageByDate[date] || 0) + 1;
  });
  
  const creditUsage = Object.entries(creditUsageByDate)
    .map(([date, count]) => ({ date, count }))
    .sort((a, b) => a.date.localeCompare(b.date));
  
  return {
    totalScans,
    topUsers,
    topTags,
    creditUsage,
  };
};